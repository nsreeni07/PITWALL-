'use client'
import { useEffect, useRef } from 'react'
import { useRaceStore } from '@/store/raceStore'

export function useViewerCount() {
  const setViewerCount = useRaceStore(s => s.setViewerCount)
  const wsRef = useRef<WebSocket | null>(null)
  const reconnectRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    function connect() {
      try {
        const ws = new WebSocket(
          process.env.NEXT_PUBLIC_WS_URL || 'ws://localhost:8080'
        )
        wsRef.current = ws

        ws.onopen = () => {
          console.log('[WS] Connected to viewer counter')
        }

        ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data)
            if (msg.type === 'viewer_count') {
              setViewerCount(msg.count)
            }
          } catch {}
        }

        ws.onclose = () => {
          console.log('[WS] Disconnected, reconnecting in 3s…')
          reconnectRef.current = setTimeout(connect, 3000)
        }

        ws.onerror = () => {
          ws.close()
        }
      } catch {
        reconnectRef.current = setTimeout(connect, 3000)
      }
    }

    connect()
    return () => {
      if (reconnectRef.current) clearTimeout(reconnectRef.current)
      wsRef.current?.close()
    }
  }, [])
}
