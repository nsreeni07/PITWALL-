'use client'
import { useEffect, useRef } from 'react'
import { useRaceStore } from '@/store/raceStore'
import { tickSimulation } from '@/lib/simulation'

export function useRaceSimulation() {
  const { cars, setCars, tickRaceTime } = useRaceStore()
  const carsRef = useRef(cars)
  const lastTimeRef = useRef<number | null>(null)
  const rafRef = useRef<number | null>(null)

  // Keep carsRef in sync
  useEffect(() => {
    carsRef.current = cars
  }, [cars])

  useEffect(() => {
    function loop(timestamp: number) {
      if (lastTimeRef.current === null) {
        lastTimeRef.current = timestamp
      }
      const delta = Math.min((timestamp - lastTimeRef.current) / 1000, 0.1) // cap at 100ms
      lastTimeRef.current = timestamp

      const updated = tickSimulation(carsRef.current, delta)
      setCars(updated)
      tickRaceTime(delta)

      rafRef.current = requestAnimationFrame(loop)
    }

    rafRef.current = requestAnimationFrame(loop)
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current)
    }
  }, []) // intentionally empty — uses refs
}
