import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Le Mans 24H — Race Control',
  description: 'Real-time motorsport simulation dashboard — Circuit de la Sarthe',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body style={{ height: '100dvh', overflow: 'hidden' }}>
        {children}
      </body>
    </html>
  )
}
