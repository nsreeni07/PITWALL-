// Le Mans-inspired circuit path as a series of [x, y] control points
// These form the main racing loop (normalized to a 800x500 viewBox)
// Path goes: Start/Finish straight → Dunlop → Ford Chicanes → Mulsanne → Indianapolis → Porsche Curves

export const TRACK_POINTS: [number, number][] = [
  // Start/Finish straight (right side, vertical)
  [620, 430],
  [620, 380],
  [618, 330],
  [615, 280],
  // Dunlop curve - sharp right
  [610, 230],
  [600, 200],
  [580, 178],
  [555, 165],
  // Ford Chicanes heading left
  [510, 158],
  [465, 155],
  [420, 150],
  [370, 148],
  // Long Mulsanne straight (top, heading left)
  [300, 150],
  [230, 152],
  [160, 158],
  [110, 170],
  // Mulsanne corner - sharp right down
  [78, 190],
  [65, 218],
  [62, 250],
  [65, 280],
  // Indianapolis section - curves back right
  [72, 310],
  [85, 338],
  [105, 358],
  [130, 370],
  [160, 375],
  // Porsche Curves - sweeping right toward bottom
  [200, 373],
  [250, 368],
  [300, 372],
  [350, 385],
  // Maison Blanche - bottom straight heading right
  [400, 395],
  [450, 400],
  [500, 408],
  [550, 418],
  [590, 425],
  [620, 430],  // back to start
]

// Pre-compute cumulative distances for even spacing
function dist(a: [number, number], b: [number, number]): number {
  const dx = b[0] - a[0]
  const dy = b[1] - a[1]
  return Math.sqrt(dx * dx + dy * dy)
}

export function buildTrackSegments() {
  const points = TRACK_POINTS
  const segments: { start: [number,number]; end: [number,number]; len: number; cumLen: number }[] = []
  let total = 0
  for (let i = 0; i < points.length - 1; i++) {
    const len = dist(points[i], points[i + 1])
    segments.push({ start: points[i], end: points[i + 1], len, cumLen: total })
    total += len
  }
  return { segments, total }
}

// Get [x, y, angle] at position t (0–1) along track
export function getPositionOnTrack(t: number, segments: ReturnType<typeof buildTrackSegments>['segments'], total: number): { x: number; y: number; angle: number } {
  const target = ((t % 1) + 1) % 1 * total
  for (const seg of segments) {
    if (seg.cumLen + seg.len >= target) {
      const frac = (target - seg.cumLen) / seg.len
      const x = seg.start[0] + (seg.end[0] - seg.start[0]) * frac
      const y = seg.start[1] + (seg.end[1] - seg.start[1]) * frac
      const angle = Math.atan2(seg.end[1] - seg.start[1], seg.end[0] - seg.start[0]) * (180 / Math.PI)
      return { x, y, angle }
    }
  }
  return { x: TRACK_POINTS[0][0], y: TRACK_POINTS[0][1], angle: 0 }
}

// Build the SVG path string from the track points
export function buildTrackPathD(points: [number, number][]): string {
  if (points.length === 0) return ''
  let d = `M ${points[0][0]} ${points[0][1]}`
  for (let i = 1; i < points.length; i++) {
    d += ` L ${points[i][0]} ${points[i][1]}`
  }
  return d
}
