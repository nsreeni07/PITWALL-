import type { Car, CarClass } from './types'
import { TEAM_NAMES } from './types'

// Deterministic initial state - same on every reload
const INITIAL_CARS: Omit<Car, 'selected'>[] = [
  // 5 Hypercars
  { id: 1,  number: '8',  class: 'Hypercar', position: 0.00, speed: 0, lapTime: 0, bestLap: 211.4, lastLap: 212.1, laps: 0, gap: 0,   teamName: TEAM_NAMES.Hypercar[0] },
  { id: 2,  number: '50', class: 'Hypercar', position: 0.06, speed: 0, lapTime: 0, bestLap: 211.8, lastLap: 213.0, laps: 0, gap: 2.3, teamName: TEAM_NAMES.Hypercar[1] },
  { id: 3,  number: '6',  class: 'Hypercar', position: 0.12, speed: 0, lapTime: 0, bestLap: 212.2, lastLap: 214.5, laps: 0, gap: 5.1, teamName: TEAM_NAMES.Hypercar[2] },
  { id: 4,  number: '2',  class: 'Hypercar', position: 0.18, speed: 0, lapTime: 0, bestLap: 212.9, lastLap: 215.8, laps: 0, gap: 8.7, teamName: TEAM_NAMES.Hypercar[3] },
  { id: 5,  number: '20', class: 'Hypercar', position: 0.24, speed: 0, lapTime: 0, bestLap: 213.4, lastLap: 216.2, laps: 0, gap: 12.4, teamName: TEAM_NAMES.Hypercar[4] },
  // 5 LMP2
  { id: 6,  number: '22', class: 'LMP2',     position: 0.30, speed: 0, lapTime: 0, bestLap: 225.1, lastLap: 226.0, laps: 0, gap: 45.2, teamName: TEAM_NAMES.LMP2[0] },
  { id: 7,  number: '38', class: 'LMP2',     position: 0.36, speed: 0, lapTime: 0, bestLap: 225.8, lastLap: 227.3, laps: 0, gap: 47.8, teamName: TEAM_NAMES.LMP2[1] },
  { id: 8,  number: '65', class: 'LMP2',     position: 0.42, speed: 0, lapTime: 0, bestLap: 226.3, lastLap: 228.1, laps: 0, gap: 51.0, teamName: TEAM_NAMES.LMP2[2] },
  { id: 9,  number: '41', class: 'LMP2',     position: 0.48, speed: 0, lapTime: 0, bestLap: 227.0, lastLap: 229.4, laps: 0, gap: 55.6, teamName: TEAM_NAMES.LMP2[3] },
  { id: 10, number: '26', class: 'LMP2',     position: 0.54, speed: 0, lapTime: 0, bestLap: 228.2, lastLap: 231.0, laps: 0, gap: 62.3, teamName: TEAM_NAMES.LMP2[4] },
  // 7 GT
  { id: 11, number: '63', class: 'GT',       position: 0.60, speed: 0, lapTime: 0, bestLap: 248.4, lastLap: 249.0, laps: 0, gap: 110.5, teamName: TEAM_NAMES.GT[0] },
  { id: 12, number: '57', class: 'GT',       position: 0.65, speed: 0, lapTime: 0, bestLap: 249.1, lastLap: 250.3, laps: 0, gap: 114.2, teamName: TEAM_NAMES.GT[1] },
  { id: 13, number: '82', class: 'GT',       position: 0.70, speed: 0, lapTime: 0, bestLap: 249.8, lastLap: 251.1, laps: 0, gap: 118.8, teamName: TEAM_NAMES.GT[2] },
  { id: 14, number: '55', class: 'GT',       position: 0.75, speed: 0, lapTime: 0, bestLap: 250.5, lastLap: 252.8, laps: 0, gap: 124.1, teamName: TEAM_NAMES.GT[3] },
  { id: 15, number: '85', class: 'GT',       position: 0.80, speed: 0, lapTime: 0, bestLap: 251.2, lastLap: 253.4, laps: 0, gap: 129.7, teamName: TEAM_NAMES.GT[4] },
  { id: 16, number: '77', class: 'GT',       position: 0.86, speed: 0, lapTime: 0, bestLap: 252.0, lastLap: 255.0, laps: 0, gap: 138.2, teamName: TEAM_NAMES.GT[5] },
  { id: 17, number: '91', class: 'GT',       position: 0.92, speed: 0, lapTime: 0, bestLap: 253.1, lastLap: 256.8, laps: 0, gap: 146.9, teamName: TEAM_NAMES.GT[6] },
]

// Base speeds per class (track-loop units per second)
const BASE_SPEED: Record<CarClass, number> = {
  Hypercar: 0.00465,  // ~215s lap
  LMP2:     0.00435,  // ~230s lap
  GT:       0.00395,  // ~253s lap
}

// Variation factor per car (slight performance difference)
const SPEED_VARIANT = [1.000, 0.998, 0.995, 0.991, 0.986,
                       1.000, 0.997, 0.994, 0.990, 0.984,
                       1.000, 0.997, 0.994, 0.990, 0.986, 0.981, 0.975]

export function createInitialCars(): Car[] {
  return INITIAL_CARS.map((c, i) => ({
    ...c,
    speed: BASE_SPEED[c.class] * SPEED_VARIANT[i] * 3600 * 13.6, // km/h approx
    lapTime: 0,
    selected: false,
  }))
}

let prevPositions: number[] = INITIAL_CARS.map(c => c.position)
let lapTimers: number[] = new Array(INITIAL_CARS.length).fill(0)

export function tickSimulation(cars: Car[], deltaSeconds: number): Car[] {
  const updated = cars.map((car, i) => {
    const baseSpeed = BASE_SPEED[car.class] * SPEED_VARIANT[i]
    // Add tiny random variation per tick
    const noise = 1 + (Math.random() - 0.5) * 0.004
    const effectiveSpeed = baseSpeed * noise
    const newPos = (car.position + effectiveSpeed * deltaSeconds + 1) % 1

    // Track lap crossings (position wraps from ~0.99 to ~0.01)
    let newLaps = car.laps
    let newLastLap = car.lastLap
    lapTimers[i] = (lapTimers[i] || 0) + deltaSeconds

    if (prevPositions[i] > 0.95 && newPos < 0.05) {
      // Crossed finish line
      newLastLap = parseFloat(lapTimers[i].toFixed(1))
      newLaps++
      lapTimers[i] = 0
    }
    prevPositions[i] = newPos

    // Simulated speed in km/h — vary a bit
    const speedKmh = Math.round(
      (car.class === 'Hypercar' ? 285 : car.class === 'LMP2' ? 265 : 240) +
      (Math.random() - 0.5) * 20
    )

    return {
      ...car,
      position: newPos,
      speed: speedKmh,
      laps: newLaps,
      lastLap: newLastLap,
      lapTime: lapTimers[i],
    }
  })

  // Recalculate gaps relative to class leader
  const leaders: Record<CarClass, number> = { Hypercar: -1, LMP2: -1, GT: -1 }
  // find leader for each class (most laps + highest position)
  const classified = [...updated].sort((a, b) => {
    if (b.laps !== a.laps) return b.laps - a.laps
    return b.position - a.position
  })
  for (const c of classified) {
    if (leaders[c.class] === -1) leaders[c.class] = c.id
  }

  return updated.map(car => {
    const leader = updated.find(c => c.id === leaders[car.class])
    if (!leader || leader.id === car.id) return { ...car, gap: 0 }
    const lapDiff = leader.laps - car.laps
    const posDiff = leader.position - car.position
    const lapLen = 1 / BASE_SPEED[car.class]
    const gapSec = lapDiff * lapLen + posDiff * lapLen
    return { ...car, gap: parseFloat(Math.max(0, gapSec).toFixed(1)) }
  })
}

export function formatLapTime(seconds: number): string {
  if (!seconds || seconds <= 0) return '--:--.---'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  const ms = Math.round((seconds % 1) * 1000)
  return `${mins}:${String(secs).padStart(2, '0')}.${String(ms).padStart(3, '0')}`
}

export function formatGap(gap: number): string {
  if (gap === 0) return 'LEADER'
  if (gap >= 60) {
    const laps = Math.floor(gap / 200)
    if (laps >= 1) return `+${laps} LAP`
  }
  return `+${gap.toFixed(1)}s`
}
