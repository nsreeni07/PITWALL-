export type CarClass = 'Hypercar' | 'LMP2' | 'GT'

export interface Car {
  id: number
  number: string
  class: CarClass
  position: number       // 0–1 loop progress along track path
  speed: number          // km/h
  lapTime: number        // seconds
  bestLap: number        // seconds
  lastLap: number        // seconds
  laps: number
  gap: number            // gap to leader in seconds
  teamName: string
  selected: boolean
}

export interface RaceState {
  cars: Car[]
  tick: number
  raceTime: number       // total elapsed seconds
  safetyCarActive: boolean
}

export type FilterClass = 'All' | CarClass

export const CLASS_COLORS: Record<CarClass, string> = {
  Hypercar: '#ff3040',
  LMP2: '#3a8eff',
  GT: '#2ecc71',
}

export const TEAM_NAMES: Record<CarClass, string[]> = {
  Hypercar: ['Toyota GR', 'Ferrari AF', 'Porsche Penske', 'Cadillac Racing', 'BMW M'],
  LMP2: ['United Auto', 'JOTA Sport', 'Cool Racing', 'Nielsen Racing', 'G-Drive'],
  GT: ['Corvette Racing', 'Aston Martin', 'BMW ROWE', 'Iron Lynx', 'Kessel Racing',
       'Inception Racing', 'TF Sport', 'SunEnergy1'],
}
