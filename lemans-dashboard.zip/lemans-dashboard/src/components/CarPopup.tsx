'use client'
import React, { useEffect, useRef } from 'react'
import { useRaceStore } from '@/store/raceStore'
import { CLASS_COLORS } from '@/lib/types'
import { formatLapTime, formatGap } from '@/lib/simulation'

export default function CarPopup() {
  const { cars, selectedCarId, selectCar } = useRaceStore()
  const popupRef = useRef<HTMLDivElement>(null)

  const car = cars.find(c => c.id === selectedCarId)

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') selectCar(null)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selectCar])

  if (!car) return null

  const color = CLASS_COLORS[car.class]

  // Stat item helper
  const Stat = ({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) => (
    <div className="flex flex-col gap-0.5">
      <span className="text-[9px] font-mono text-race-dim tracking-widest uppercase">{label}</span>
      <span
        className={`text-sm font-mono font-bold tabular-nums ${highlight ? '' : 'text-race-text'}`}
        style={highlight ? { color } : undefined}
      >
        {value}
      </span>
    </div>
  )

  return (
    <div
      ref={popupRef}
      className="absolute inset-0 flex items-center justify-center z-50 pointer-events-none"
    >
      <div
        className="
          pointer-events-auto
          relative w-[340px] max-w-[90vw]
          rounded-lg overflow-hidden
          border border-white/10
          shadow-2xl
        "
        style={{
          background: 'rgba(8, 12, 16, 0.92)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          boxShadow: `0 0 40px rgba(0,0,0,0.8), 0 0 20px ${color}25, inset 0 1px 0 rgba(255,255,255,0.06)`,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top accent bar */}
        <div
          className="h-[3px] w-full"
          style={{
            background: `linear-gradient(90deg, ${color}, ${color}88, transparent)`,
          }}
        />

        {/* Header */}
        <div className="flex items-start justify-between px-4 pt-3 pb-2">
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <span
                className="text-[10px] font-mono px-1.5 py-0.5 rounded-sm font-bold tracking-widest"
                style={{
                  color,
                  border: `1px solid ${color}50`,
                  background: `${color}20`,
                }}
              >
                {car.class.toUpperCase()}
              </span>
              <span className="text-[10px] font-mono text-race-dim tracking-wider">
                {car.teamName}
              </span>
            </div>
            <h2
              className="text-2xl font-mono font-black tracking-tight"
              style={{ color }}
            >
              CAR #{car.number}
            </h2>
          </div>
          <button
            onClick={() => selectCar(null)}
            className="text-race-dim hover:text-white transition-colors mt-1 p-1"
            aria-label="Close"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M1 1l12 12M13 1L1 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {/* Stats grid */}
        <div
          className="grid grid-cols-3 gap-3 mx-4 mb-3 p-3 rounded"
          style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
        >
          <Stat label="Speed" value={`${car.speed} km/h`} highlight />
          <Stat label="Last Lap" value={formatLapTime(car.lastLap)} />
          <Stat label="Best Lap" value={formatLapTime(car.bestLap)} />
          <Stat label="Gap" value={formatGap(car.gap)} />
          <Stat label="Laps" value={String(car.laps)} />
          <Stat label="Position" value={`${(car.position * 13.626).toFixed(2)} km`} />
        </div>

        {/* YouTube embed */}
        <div className="mx-4 mb-3">
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="w-1 h-3" style={{ background: color }} />
            <span className="text-[9px] font-mono text-race-dim tracking-widest uppercase">
              Onboard Feed
            </span>
            <div className="flex-1 h-px bg-white/5" />
            <span className="text-[8px] font-mono text-race-dim/50">LIVE</span>
            <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          </div>
          <div
            className="relative rounded overflow-hidden"
            style={{ aspectRatio: '16/9', background: '#000' }}
          >
            <iframe
              src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=0&mute=1&controls=1&rel=0&modestbranding=1"
              title={`Car #${car.number} onboard`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="absolute inset-0 w-full h-full"
              style={{ border: 'none' }}
            />
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="flex items-center justify-between px-4 py-2 border-t border-white/5"
          style={{ background: 'rgba(0,0,0,0.3)' }}
        >
          <span className="text-[9px] font-mono text-race-dim tracking-widest">
            PRESS ESC TO CLOSE
          </span>
          <div className="flex items-center gap-1">
            <div className="w-1 h-1 rounded-full bg-race-accent animate-pulse" />
            <span className="text-[9px] font-mono text-race-dim">TELEMETRY LIVE</span>
          </div>
        </div>
      </div>
    </div>
  )
}
