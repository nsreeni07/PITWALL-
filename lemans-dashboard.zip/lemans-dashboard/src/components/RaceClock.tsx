'use client'
import React from 'react'
import { useRaceStore } from '@/store/raceStore'

function formatRaceTime(seconds: number): string {
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

// 24h race - time remaining
const RACE_DURATION = 24 * 3600

export default function RaceClock() {
  const raceTime = useRaceStore(s => s.raceTime)
  const remaining = Math.max(0, RACE_DURATION - raceTime)
  const elapsed = formatRaceTime(raceTime)
  const rem = formatRaceTime(remaining)
  const progress = Math.min(raceTime / RACE_DURATION, 1)

  return (
    <div className="flex items-center gap-3">
      {/* Progress bar */}
      <div className="hidden sm:flex flex-col gap-0.5">
        <div className="flex justify-between">
          <span className="text-[8px] font-mono text-race-dim">ELAPSED</span>
          <span className="text-[8px] font-mono text-race-dim">REMAINING</span>
        </div>
        <div className="relative w-32 h-1.5 rounded-full bg-white/5 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-1000"
            style={{
              width: `${progress * 100}%`,
              background: 'linear-gradient(90deg, #e8a020, #ff6030)',
            }}
          />
        </div>
        <div className="flex justify-between">
          <span className="text-[8px] font-mono text-race-accent tabular-nums">{elapsed}</span>
          <span className="text-[8px] font-mono text-race-dim tabular-nums">{rem}</span>
        </div>
      </div>

      {/* Main clock */}
      <div className="text-center">
        <div className="text-[8px] font-mono text-race-dim tracking-widest mb-0.5">RACE TIME</div>
        <div className="text-lg font-mono font-bold text-white tabular-nums leading-none tracking-wider">
          {elapsed}
        </div>
      </div>
    </div>
  )
}
