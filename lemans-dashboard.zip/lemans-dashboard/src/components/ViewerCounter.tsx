'use client'
import React from 'react'
import { useRaceStore } from '@/store/raceStore'
import { useViewerCount } from '@/hooks/useViewerCount'

export default function ViewerCounter() {
  useViewerCount()
  const viewerCount = useRaceStore(s => s.viewerCount)

  return (
    <div
      className="flex items-center gap-2.5 px-3 py-1.5 rounded"
      style={{
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid rgba(255,255,255,0.08)',
      }}
    >
      {/* Live pulse dot */}
      <div className="relative flex items-center justify-center w-2 h-2">
        <div className="absolute w-2 h-2 rounded-full bg-red-500 animate-ping opacity-75" />
        <div className="w-1.5 h-1.5 rounded-full bg-red-500" />
      </div>
      <div>
        <div className="text-[8px] font-mono text-race-dim tracking-[0.2em] uppercase leading-none mb-0.5">
          Live Viewers
        </div>
        <div className="text-sm font-mono font-bold text-white tabular-nums leading-none">
          {viewerCount.toLocaleString()}
        </div>
      </div>
    </div>
  )
}
