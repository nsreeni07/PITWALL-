'use client'
import React from 'react'
import dynamic from 'next/dynamic'
import { useRaceSimulation } from '@/hooks/useRaceSimulation'

// Dynamic imports to avoid SSR issues with canvas/requestAnimationFrame
const TrackView = dynamic(() => import('@/components/TrackView'), { ssr: false })
const TimingTable = dynamic(() => import('@/components/TimingTable'), { ssr: false })
const CarPopup = dynamic(() => import('@/components/CarPopup'), { ssr: false })
const ViewerCounter = dynamic(() => import('@/components/ViewerCounter'), { ssr: false })
const RaceClock = dynamic(() => import('@/components/RaceClock'), { ssr: false })

export default function Dashboard() {
  // Start simulation loop
  useRaceSimulation()

  return (
    <div className="min-h-screen bg-race-bg flex flex-col" style={{ fontFamily: 'JetBrains Mono, Fira Code, monospace' }}>
      {/* Top bar */}
      <header
        className="flex items-center justify-between px-4 py-2 border-b border-race-border"
        style={{
          background: 'rgba(8,12,16,0.95)',
          backdropFilter: 'blur(10px)',
        }}
      >
        {/* Left: event identity */}
        <div className="flex items-center gap-3">
          {/* ACO-style logo mark */}
          <div className="flex items-center gap-1.5">
            <div
              className="w-8 h-8 rounded flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #e8a020 0%, #c07010 100%)',
                boxShadow: '0 0 12px rgba(232,160,32,0.3)',
              }}
            >
              <span className="text-black text-[9px] font-black tracking-tighter leading-none text-center">
                24H
              </span>
            </div>
            <div>
              <div className="text-white text-xs font-bold tracking-widest leading-none">LE MANS</div>
              <div className="text-race-dim text-[8px] tracking-[0.2em] leading-none mt-0.5">RACE CONTROL</div>
            </div>
          </div>

          <div className="w-px h-6 bg-race-border" />

          {/* Race status */}
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-mono text-green-400 tracking-widest">RACE LIVE</span>
          </div>
        </div>

        {/* Center: race clock */}
        <RaceClock />

        {/* Right: viewer counter */}
        <ViewerCounter />
      </header>

      {/* Main content */}
      <main className="flex-1 flex flex-col lg:flex-row gap-0 overflow-hidden" style={{ minHeight: 0 }}>
        {/* Track view — takes most of the space */}
        <div
          className="relative flex-1 lg:flex-[3]"
          style={{
            minHeight: '300px',
            borderRight: '1px solid #1e2d3d',
          }}
        >
          <TrackView />
          <CarPopup />
        </div>

        {/* Timing table */}
        <div
          className="lg:flex-[2] lg:max-w-[520px] border-t lg:border-t-0 border-race-border overflow-hidden flex flex-col"
          style={{ minHeight: '200px', maxHeight: '100%' }}
        >
          <TimingTable />
        </div>
      </main>

      {/* Bottom status bar */}
      <footer
        className="flex items-center justify-between px-4 py-1.5 border-t border-race-border"
        style={{ background: 'rgba(8,12,16,0.9)' }}
      >
        <div className="flex items-center gap-4">
          <span className="text-[8px] font-mono text-race-dim/50 tracking-widest">
            CIRCUIT DE LA SARTHE · 13.626 KM
          </span>
          <span className="text-[8px] font-mono text-race-dim/30">
            SIM DATA — NOT OFFICIAL TIMING
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[8px] font-mono text-race-dim/30">FIA WEC</span>
          <div className="w-px h-2.5 bg-race-border" />
          <span className="text-[8px] font-mono text-race-dim/30">ACO</span>
        </div>
      </footer>
    </div>
  )
}
