'use client'
import React, { useMemo } from 'react'
import { useRaceStore } from '@/store/raceStore'
import type { FilterClass } from '@/lib/types'
import { CLASS_COLORS } from '@/lib/types'
import { formatLapTime, formatGap } from '@/lib/simulation'

const FILTERS: FilterClass[] = ['All', 'Hypercar', 'LMP2', 'GT']

export default function TimingTable() {
  const { cars, selectedCarId, selectCar, filterClass, setFilterClass } = useRaceStore()

  const sorted = useMemo(() => {
    const filtered = filterClass === 'All' ? cars : cars.filter(c => c.class === filterClass)

    return [...filtered].sort((a, b) => {
      if (b.laps !== a.laps) return b.laps - a.laps
      return b.position - a.position
    })
  }, [cars, filterClass])

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-race-border">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-4 bg-race-accent" />
          <span className="text-xs font-mono font-bold text-race-text tracking-widest uppercase">
            Live Timing
          </span>
        </div>
        {/* Filter tabs */}
        <div className="flex gap-1">
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setFilterClass(f)}
              className={`
                px-2 py-0.5 text-[10px] font-mono tracking-wider rounded-sm transition-all duration-150
                ${filterClass === f
                  ? 'bg-race-accent text-black font-bold'
                  : 'text-race-dim hover:text-race-text border border-race-border hover:border-race-dim'
                }
              `}
            >
              {f.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Column headers */}
      <div className="grid grid-cols-[28px_36px_68px_1fr_88px_78px] gap-x-2 px-4 py-1.5 border-b border-race-border/50">
        {['POS', '#', 'CLASS', 'TEAM', 'GAP', 'LAST LAP'].map((h, i) => (
          <span
            key={h}
            className={`text-[9px] font-mono text-race-dim tracking-widest ${
              i >= 3 ? 'text-right' : ''
            }`}
          >
            {h}
          </span>
        ))}
      </div>

      {/* Rows */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        {sorted.map((car, idx) => {
          const isSelected = car.id === selectedCarId
          const color = CLASS_COLORS[car.class]
          const isLeader = idx === 0 || (filterClass !== 'All' && car.gap === 0)

          return (
            <div
              key={car.id}
              onClick={() => selectCar(isSelected ? null : car.id)}
              className={`
                grid grid-cols-[28px_36px_68px_1fr_88px_78px] gap-x-2 px-4 py-1.5
                cursor-pointer transition-all duration-100 border-b border-race-border/20
                ${isSelected
                  ? 'bg-white/5 border-l-2'
                  : 'hover:bg-white/[0.02] border-l-2 border-l-transparent'
                }
              `}
              style={isSelected ? { borderLeftColor: color } : undefined}
            >
              {/* Position */}
              <span className="text-[11px] font-mono font-bold text-race-dim self-center">
                {idx + 1}
              </span>

              {/* Car number */}
              <span
                className="text-[11px] font-mono font-bold self-center"
                style={{ color }}
              >
                #{car.number}
              </span>

              {/* Class badge */}
              <div className="flex items-center self-center">
                <span
                  className="text-[9px] font-mono px-1.5 py-0.5 rounded-sm font-bold tracking-wider"
                  style={{
                    color,
                    border: `1px solid ${color}40`,
                    backgroundColor: `${color}15`,
                  }}
                >
                  {car.class.toUpperCase()}
                </span>
              </div>

              {/* Team name */}
              <span className="text-[10px] font-mono text-race-dim self-center truncate">
                {car.teamName}
              </span>

              {/* Gap */}
              <span className={`
                text-[10px] font-mono text-right self-center
                ${isLeader ? 'text-race-accent font-bold' : 'text-race-text'}
              `}>
                {formatGap(car.gap)}
              </span>

              {/* Last lap */}
              <span className="text-[10px] font-mono text-race-text text-right self-center tabular-nums">
                {formatLapTime(car.lastLap)}
              </span>
            </div>
          )
        })}
      </div>

      {/* Footer stats */}
      <div className="px-4 py-2 border-t border-race-border flex gap-4">
        {(['Hypercar', 'LMP2', 'GT'] as const).map(cls => {
          const count = cars.filter(c => c.class === cls).length
          return (
            <div key={cls} className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: CLASS_COLORS[cls] }} />
              <span className="text-[9px] font-mono text-race-dim">
                {count} {cls.toUpperCase()}
              </span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
