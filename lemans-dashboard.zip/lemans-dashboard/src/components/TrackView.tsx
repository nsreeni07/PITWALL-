'use client'
import React, { useCallback, useMemo } from 'react'
import { useRaceStore } from '@/store/raceStore'
import { CLASS_COLORS } from '@/lib/types'
import {
  TRACK_POINTS,
  buildTrackSegments,
  getPositionOnTrack,
  buildTrackPathD,
} from '@/lib/track'

// Pre-build track geometry once
const { segments, total } = buildTrackSegments()
const TRACK_PATH_D = buildTrackPathD(TRACK_POINTS)

// Pit lane indicator zones
const SECTOR_LABELS = [
  { x: 625, y: 355, label: 'S/F' },
  { x: 565, y: 145, label: 'FORD' },
  { x: 50,  y: 245, label: 'MULSANNE' },
  { x: 115, y: 388, label: 'INDY' },
  { x: 420, y: 415, label: 'MAISON BLANCHE' },
]

export default function TrackView() {
  const { cars, selectedCarId, selectCar } = useRaceStore()

  const handleCarClick = useCallback((e: React.MouseEvent, carId: number) => {
    e.stopPropagation()
    selectCar(selectedCarId === carId ? null : carId)
  }, [selectedCarId, selectCar])

  const handleBackgroundClick = useCallback(() => {
    selectCar(null)
  }, [selectCar])

  // Calculate positions for all cars
  const carPositions = useMemo(() => {
    return cars.map(car => ({
      ...getPositionOnTrack(car.position, segments, total),
      car,
    }))
  }, [cars])

  return (
    <div
      className="relative w-full h-full flex items-center justify-center"
      onClick={handleBackgroundClick}
    >
      {/* Circuit name watermark */}
      <div className="absolute top-3 left-4 z-10">
        <div className="text-[10px] font-mono text-race-dim tracking-[0.3em] uppercase">Circuit de la Sarthe</div>
        <div className="text-[9px] font-mono text-race-dim/50 tracking-wider">Le Mans · 13.626 km</div>
      </div>

      {/* Track SVG */}
      <svg
        viewBox="0 0 700 500"
        className="w-full h-full"
        style={{ maxHeight: '100%' }}
      >
        <defs>
          {/* Glowing track filter */}
          <filter id="trackGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <filter id="carGlow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <filter id="selectedGlow" x="-150%" y="-150%" width="400%" height="400%">
            <feGaussianBlur stdDeviation="5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          {/* Track gradient */}
          <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#080c10" />
            <stop offset="100%" stopColor="#0a1018" />
          </linearGradient>

          {/* Asphalt texture for track body */}
          <pattern id="asphalt" x="0" y="0" width="4" height="4" patternUnits="userSpaceOnUse">
            <rect width="4" height="4" fill="#1a1f26" />
            <circle cx="1" cy="1" r="0.3" fill="#151a20" />
            <circle cx="3" cy="3" r="0.3" fill="#1e242c" />
          </pattern>
        </defs>

        {/* Background */}
        <rect width="700" height="500" fill="url(#bgGrad)" />

        {/* Infield grass areas */}
        <ellipse cx="350" cy="280" rx="230" ry="110" fill="#0d1a0e" opacity="0.6" />

        {/* Track outer edge (wide stroke = track width) */}
        <path
          d={TRACK_PATH_D}
          fill="none"
          stroke="#2a3540"
          strokeWidth="22"
          strokeLinejoin="round"
          strokeLinecap="round"
        />

        {/* Track surface */}
        <path
          d={TRACK_PATH_D}
          fill="none"
          stroke="#1e2830"
          strokeWidth="18"
          strokeLinejoin="round"
          strokeLinecap="round"
        />

        {/* Track centerline (subtle) */}
        <path
          d={TRACK_PATH_D}
          fill="none"
          stroke="#253040"
          strokeWidth="1"
          strokeLinejoin="round"
          strokeLinecap="round"
          strokeDasharray="12 8"
          opacity="0.4"
        />

        {/* Track glow overlay */}
        <path
          d={TRACK_PATH_D}
          fill="none"
          stroke="rgba(58, 142, 255, 0.04)"
          strokeWidth="22"
          strokeLinejoin="round"
          strokeLinecap="round"
          filter="url(#trackGlow)"
        />

        {/* Start/Finish line */}
        <line x1="620" y1="415" x2="620" y2="445" stroke="white" strokeWidth="3" opacity="0.8" />
        <rect x="614" y="418" width="6" height="4" fill="white" />
        <rect x="614" y="426" width="6" height="4" fill="white" />
        <rect x="614" y="434" width="6" height="4" fill="white" />
        <rect x="618" y="422" width="6" height="4" fill="#111" />
        <rect x="618" y="430" width="6" height="4" fill="#111" />

        {/* Sector labels */}
        {SECTOR_LABELS.map((s) => (
          <text
            key={s.label}
            x={s.x}
            y={s.y}
            fontSize="8"
            fill="rgba(150, 170, 190, 0.35)"
            fontFamily="monospace"
            letterSpacing="1"
            textAnchor="middle"
          >
            {s.label}
          </text>
        ))}

        {/* Cars */}
        {carPositions.map(({ x, y, angle, car }) => {
          const color = CLASS_COLORS[car.class]
          const isSelected = car.id === selectedCarId
          const r = isSelected ? 7 : 5

          return (
            <g
              key={car.id}
              transform={`translate(${x}, ${y})`}
              onClick={(e) => handleCarClick(e, car.id)}
              style={{ cursor: 'pointer' }}
            >
              {/* Selection ring */}
              {isSelected && (
                <circle
                  r={14}
                  fill="none"
                  stroke={color}
                  strokeWidth="1.5"
                  opacity="0.6"
                  filter="url(#selectedGlow)"
                >
                  <animate
                    attributeName="r"
                    values="12;16;12"
                    dur="1.5s"
                    repeatCount="indefinite"
                  />
                  <animate
                    attributeName="opacity"
                    values="0.8;0.3;0.8"
                    dur="1.5s"
                    repeatCount="indefinite"
                  />
                </circle>
              )}

              {/* Car glow */}
              <circle r={r + 2} fill={color} opacity="0.15" filter="url(#carGlow)" />

              {/* Car body */}
              <circle
                r={r}
                fill={color}
                stroke={isSelected ? 'white' : color}
                strokeWidth={isSelected ? 1.5 : 0.5}
                opacity={isSelected ? 1 : 0.85}
              />

              {/* Car number */}
              <text
                fontSize={isSelected ? "5.5" : "5"}
                fill="white"
                textAnchor="middle"
                dominantBaseline="central"
                fontFamily="monospace"
                fontWeight="bold"
                style={{ pointerEvents: 'none', userSelect: 'none' }}
              >
                {car.number}
              </text>
            </g>
          )
        })}
      </svg>

      {/* Legend */}
      <div className="absolute bottom-3 left-4 flex gap-4">
        {(['Hypercar', 'LMP2', 'GT'] as const).map(cls => (
          <div key={cls} className="flex items-center gap-1.5">
            <div
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: CLASS_COLORS[cls], boxShadow: `0 0 6px ${CLASS_COLORS[cls]}` }}
            />
            <span className="text-[10px] font-mono text-race-dim uppercase tracking-wider">{cls}</span>
          </div>
        ))}
      </div>

      {/* Click hint */}
      <div className="absolute bottom-3 right-4 text-[9px] font-mono text-race-dim/40 tracking-wider">
        CLICK CAR FOR DETAIL
      </div>
    </div>
  )
}
