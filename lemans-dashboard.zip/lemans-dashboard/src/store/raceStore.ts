import { create } from 'zustand'
import type { Car, FilterClass } from '@/lib/types'
import { createInitialCars } from '@/lib/simulation'

interface RaceStore {
  cars: Car[]
  selectedCarId: number | null
  filterClass: FilterClass
  viewerCount: number
  raceTime: number
  safetyCarActive: boolean

  setCars: (cars: Car[]) => void
  selectCar: (id: number | null) => void
  setFilterClass: (cls: FilterClass) => void
  setViewerCount: (count: number) => void
  tickRaceTime: (delta: number) => void
}

export const useRaceStore = create<RaceStore>((set) => ({
  cars: createInitialCars(),
  selectedCarId: null,
  filterClass: 'All',
  viewerCount: 0,
  raceTime: 0,
  safetyCarActive: false,

  setCars: (cars) => set({ cars }),

  selectCar: (id) => set((state) => ({
    selectedCarId: id,
    cars: state.cars.map(c => ({ ...c, selected: c.id === id })),
  })),

  setFilterClass: (cls) => set({ filterClass: cls }),
  setViewerCount: (count) => set({ viewerCount: count }),
  tickRaceTime: (delta) => set((state) => ({ raceTime: state.raceTime + delta })),
}))
