# 🏁 Le Mans 24H — Race Control Dashboard

A real-time motorsport simulation dashboard inspired by Le Mans ACO race control systems. Built with Next.js, React, TypeScript, TailwindCSS, Zustand, and WebSocket.

![Dashboard Preview](preview.png)

---

## ✨ Features

- **Track Visualization** — SVG Circuit de la Sarthe with 17 animated cars running at 60fps
- **Live Timing Table** — Dynamic leaderboard with class filtering, updating in real time
- **Car Detail Popup** — Glassmorphism panel with telemetry stats + embedded onboard video
- **Live Viewer Counter** — Real WebSocket connection tracking concurrent visitors
- **Race Clock** — 24-hour race elapsed/remaining timer
- **Dark Motorsport UI** — Control room aesthetic with race-grade typography

---

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn

### Install dependencies

```bash
npm install
```

### Run both servers

**Terminal 1 — WebSocket server (viewer counter):**
```bash
npm run ws-server
```

**Terminal 2 — Next.js dev server:**
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

> **Tip:** Open multiple browser tabs to see the viewer count go up in real time!

---

## 🏗️ Project Structure

```
lemans-dashboard/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout with metadata
│   │   ├── page.tsx            # Entry point
│   │   └── globals.css         # Global styles + fonts
│   ├── components/
│   │   ├── Dashboard.tsx       # Main layout orchestrator
│   │   ├── TrackView.tsx       # SVG circuit + animated car dots
│   │   ├── TimingTable.tsx     # Live leaderboard with filters
│   │   ├── CarPopup.tsx        # Glassmorphism car detail panel
│   │   ├── ViewerCounter.tsx   # WebSocket viewer count display
│   │   └── RaceClock.tsx       # 24h race timer
│   ├── hooks/
│   │   ├── useRaceSimulation.ts  # requestAnimationFrame simulation loop
│   │   └── useViewerCount.ts     # WebSocket client hook
│   ├── store/
│   │   └── raceStore.ts          # Zustand global state
│   └── lib/
│       ├── types.ts              # TypeScript interfaces
│       ├── track.ts              # SVG path geometry + position math
│       └── simulation.ts         # Race physics + lap timing engine
├── ws-server/
│   └── server.js               # Node.js WebSocket server
├── .env.local                  # WS URL config
├── next.config.js
├── tailwind.config.ts
└── tsconfig.json
```

---

## 🎮 How to Use

| Interaction | Action |
|---|---|
| Click a car dot | Opens telemetry popup |
| Click outside popup | Closes popup |
| Press `Escape` | Closes popup |
| Click timing row | Selects + highlights car on track |
| Filter buttons | Filter timing by class |

---

## 🚗 Car Classes

| Class | Color | Count | Lap Time (approx) |
|---|---|---|---|
| Hypercar | 🔴 Red | 5 | ~3:32 |
| LMP2 | 🔵 Blue | 5 | ~3:50 |
| GT | 🟢 Green | 7 | ~4:13 |

---

## 🔌 WebSocket Protocol

The WS server broadcasts a single message type:

```json
{
  "type": "viewer_count",
  "count": 3
}
```

Sent to all clients whenever anyone connects or disconnects.

### Environment Variables

| Variable | Default | Description |
|---|---|---|
| `NEXT_PUBLIC_WS_URL` | `ws://localhost:8080` | WebSocket server URL |
| `PORT` | `8080` | WS server port |

---

## ⚡ Performance Notes

- Cars animate via `requestAnimationFrame` at native display refresh rate
- Zustand store uses shallow comparison to avoid unnecessary re-renders
- SVG positions computed with pre-built segment lookup (O(n) path traversal)
- Track geometry pre-calculated at module load time
- Timing table rows use React key-based reconciliation for minimal DOM changes

---

## 🛠️ Production Deployment

1. Build Next.js:
```bash
npm run build && npm start
```

2. Deploy WS server separately (e.g. Railway, Fly.io, or same server):
```bash
node ws-server/server.js
```

3. Set `NEXT_PUBLIC_WS_URL` to your production WS endpoint in your deployment environment.

---

## 📐 Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 14 (App Router) |
| UI | React 18 + TypeScript |
| Styling | TailwindCSS |
| State | Zustand |
| Animation | requestAnimationFrame (native) |
| Real-time | WebSocket (ws library) |
| Fonts | JetBrains Mono + Rajdhani |
