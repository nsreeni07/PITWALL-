const { WebSocketServer } = require('ws')

const PORT = process.env.PORT || 8080
const wss = new WebSocketServer({ port: PORT })

let viewerCount = 0

function broadcastViewerCount() {
  const message = JSON.stringify({ type: 'viewer_count', count: viewerCount })
  wss.clients.forEach((client) => {
    if (client.readyState === client.OPEN) {
      client.send(message)
    }
  })
}

wss.on('connection', (ws) => {
  viewerCount++
  console.log(`[WS] Client connected — viewers: ${viewerCount}`)
  broadcastViewerCount()

  ws.on('close', () => {
    viewerCount = Math.max(0, viewerCount - 1)
    console.log(`[WS] Client disconnected — viewers: ${viewerCount}`)
    broadcastViewerCount()
  })

  ws.on('error', (err) => {
    console.error('[WS] Error:', err.message)
  })

  // Send current count immediately to new connection
  if (ws.readyState === ws.OPEN) {
    ws.send(JSON.stringify({ type: 'viewer_count', count: viewerCount }))
  }
})

wss.on('listening', () => {
  console.log(`✅ Le Mans WS Server running on ws://localhost:${PORT}`)
  console.log(`   Tracking live viewer count in real-time`)
})

wss.on('error', (err) => {
  console.error('[WS Server] Error:', err)
})
